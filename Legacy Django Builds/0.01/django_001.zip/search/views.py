from django.shortcuts import render

import operator

from django.db.models import Q
from django.http import HttpResponse
from django.views import generic

from .models import Test

class IndexView(generic.ListView):
    template_name = 'search/index.html'
    context_object_name = 'head_values'

    def get_queryset(self):
        """
        Return the first survey variable in the dataset. 
        """
        return Test.objects.all()
 
class DetailView(generic.DetailView):
    template_name = 'search/detail.html'
    model = Test

    '''
    # WORK IN PROGRESS
    def get_queryset(self):
        result = super(DetailView, self).get_queryset()

        query = self.request.GET.get('q')
        if query:
            result = result.filter(index_num
            )

        return result
    '''


'''
class BlogSearchListView(BlogListView):
    """
    Display a Blog List page filtered by the search query.
    """
    paginate_by = 10

    def get_queryset(self):
        result = super(BlogSearchListView, self).get_queryset()

        query = self.request.GET.get('q')
        if query:
            query_list = query.split()
            result = result.filter(
                reduce(operator.and_,
                       (Q(title__icontains=q) for q in query_list)) |
                reduce(operator.and_,
                       (Q(content__icontains=q) for q in query_list))
            )

        return result
'''