from django.shortcuts import render

import operator

from django.db.models import Q
from django.http import HttpResponse
from django.views import generic

from .models import Test

class IndexView(generic.ListView):
    template_name = 'search/index.html'
    context_object_name = 'head_values'

    def get_queryset(self):
        """
        Return the first survey variable in the dataset. 
        """
        return Test.objects.all()
 
class DetailView(generic.ListView):
    template_name = 'search/detail.html'

    def get_queryset(self):
        result = Test.objects.all()

        query = self.request.GET.get('q')
        if query:
            result = result.filter(index_num = query)
            return result
        else:
        	pass
 